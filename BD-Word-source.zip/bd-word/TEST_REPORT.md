# Test report — honest status

**Environment limits:** written in a sandbox without internet; `npm install`, the build, the tests, the Windows installer and the APK were **not run**. Nothing below is verified.

## Automated tests written (`npm test`) — NOT YET RUN
| Area | Test |
|---|---|
| DOCX export | valid zip, Bangla text present, Heading1 style, table XML |
| DOCX round-trip | export → mammoth re-import keeps title, Bangla text, table |
| Large documents | 3000 paragraphs export < 30 s |
| Empty document | exports without error |
| Corrupted file | invalid DOCX rejected |
| TXT | HTML escaping |

## Not covered by automated tests (manual checklist to run once built)
Create/save/reopen; autosave & recovery after killing the app; undo/redo; each formatting button; tables (merge/split/resize); image insert/resize; find/replace; Open a real Word-made DOCX; PDF export; Print; Bangla typing in Windows and Android; offline mode (airplane mode); phone/tablet layouts; Ctrl shortcuts in the installed Windows app; delete/restore; backup/restore.

## Known risks
First compile may show TypeScript/dependency errors (strict typing is relaxed; `vite build` does not type-check). Tauri/Capacitor plugin versions may need bumping. Android file-save uses the share sheet.
