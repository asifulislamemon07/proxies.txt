# BD Word — free, offline word processor

React + TypeScript + TipTap (ProseMirror) editor, packaged with **Tauri v2** (Windows `.exe`) and **Capacitor** (Android `.apk`).
Documents are stored on the device (IndexedDB). No account, no server, no subscription.

> **Status: first source release. It has NOT yet been compiled or tested** (the environment it was written in had no internet).
> Expect to fix small build errors on the first run. See `TEST_REPORT.md` for exactly what is untested.

## Easiest way to get the installers (no programming needed) — GitHub Actions
1. Create a free account at github.com and a new **private** repository.
2. Upload every file of this project (drag-and-drop in the browser works; keep the folder structure, including `.github`).
3. Open the **Actions** tab → **Build BD Word installers** → **Run workflow**.
4. After ~15–25 minutes, open the finished run and download the artifacts:
   - `BD-Word-Setup-exe` → `BD-Word-Setup.exe` (Windows 10/11 installer)
   - `BD-Word-apk` → `BD-Word.apk` (Android)
5. If a step fails (red ✗), open it, copy the error text and send it to me — I will fix the code.

## Build on your own computer instead
Needs: Node.js 20+, Rust (rustup.rs) and "Desktop development with C++" (Visual Studio Build Tools) for Windows; Android Studio + JDK 17 for Android. Roughly 8–10 GB of disk space in total.
```
npm install
npm run dev            # test in the browser at http://localhost:5173
npm test               # automated tests (DOCX export/round-trip, Bangla, big docs, corrupt files)
npm run icons          # generate Windows icons from app-icon.png
npm run tauri -- build # → src-tauri/target/release/bundle/nsis/BD Word_1.0.0_x64-setup.exe
npm run build && npx cap add android && npx cap sync android
cd android && ./gradlew assembleDebug   # → android/app/build/outputs/apk/debug/app-debug.apk
```
`npm install` creates `package-lock.json`; commit it afterwards for reproducible builds.

## Installing
- **Windows:** double-click `BD-Word-Setup.exe`. Windows SmartScreen may warn "unknown publisher" because the installer is not code-signed (signing certificates cost money) → *More info → Run anyway*. Uninstall from Settings → Apps.
- **Android:** copy `BD-Word.apk` to the phone, open it, allow "Install unknown apps" for your file manager/browser when asked. The CI build is signed with Android's *debug* key, which is fine for personal installs. For Google Play or long-term updates, create your own release keystore (`keytool -genkey -v -keystore bdword.jks -alias bdword -keyalg RSA -keysize 2048 -validity 10000`), configure it in `android/app/build.gradle`, and build with `./gradlew assembleRelease`. **Keep the keystore safe** – without it you cannot publish updates.

## Where documents are stored
Inside the app's local database on the device. Windows: the app's WebView2 data folder under `%LOCALAPPDATA%\com.bdword.app`. Android: private app storage. **Uninstalling or clearing app data deletes them** – use *File → Backup* regularly and keep the backup file elsewhere. Export DOCX/PDF/TXT/HTML via the system save dialog (Windows) or share sheet (Android).

## What works (implemented in code)
- Documents: new, templates (18 built-in), open `.docx/.txt/.html`, autosave (1.2 s), recover last document on start, rename, duplicate, save a copy, close, trash + restore + delete forever (with confirmation), backup/restore (never overwrites), unsaved/failed-save indicator, unsaved-changes warning on exit.
- Home: undo/redo, cut/copy/paste-plain, select all, find/replace (next/previous/replace all), font family/size/+/-, B/I/U/S, sub/superscript, colors, highlight, clear formatting, change case, alignment, bullet/numbered/nested lists, indent, line & paragraph spacing, styles (Normal, Title, Subtitle, Heading 1–6, Quote, Caption), formatting marks.
- Insert: page break, blank page, line, tables (insert, add/delete rows/cols, merge/split, header row, shading, column resize), images (insert, width, align, alt text, delete), hyperlinks, date/time, symbols (incl. ৳), table of contents, header/footer text, page numbers.
- Layout: A4/A3/A5/B5/Letter/Legal, orientation, margins (presets + custom mm), 1–3 columns, page color, page-number position.
- References: TOC insert/update, sources, citations, bibliography.
- Review: spelling on/off (browser engine), language tag, word/char/paragraph/selection count, read-only mode, accessibility check.
- View: print/draft/read modes, zoom, fit width/page, ruler, navigation pane (heading outline), formatting marks, full screen, dark mode.
- Export: DOCX (editable), PDF, TXT, HTML. Print (Windows). Shortcuts: Ctrl+N/O/S/Shift+S/P/F/H/B/I/U/Z/Y/A/K, Ctrl+Enter (page break), F11.

## Not implemented (do not expect these yet)
Track changes, comments, compare documents, grammar check, footnotes/endnotes, cross-references/index/captions lists, text boxes, shapes, math equations, image cropping/text wrapping, bookmarks/internal links, section breaks with different page setups, paragraph borders/shading, custom styles, character spacing/text effects, multi-page side-by-side view, RTL-specific controls (browser `dir="auto"` handles basic Arabic/Hebrew, Bangla is LTR).

## Known limitations (honest notes)
- DOCX: round-trip is checked only by the included automated tests, not against Microsoft Word. Pagination, fonts and advanced formatting can differ. WebP/SVG images are skipped on DOCX export (a warning is shown). DOCX import (mammoth) drops headers/footers, comments, tracked changes, text boxes, footnotes.
- PDF export renders pages as images (not selectable text, larger files). Windows Print uses the system print dialog, which can also "Save as PDF" with real text. Printing on Android: export PDF and print from a PDF viewer.
- Header/footer appear on every page in print/DOCX; on screen they show once. Page count on screen is an estimate.
- Spell-check uses the WebView's built-in engine: works offline on Windows only if language packs are installed in Windows (Settings → Time & language); on Android it uses the keyboard's dictionary. Bangla spell-check depends on those system dictionaries.
- Fonts: only fonts installed on the device are available; others fall back. Common Bangla fonts: Nirmala UI (Windows, built in), Noto Sans Bengali (Android).
- Find does not match text split across differently formatted runs.

## Licenses
All dependencies are permissively licensed (MIT / Apache-2.0 / BSD): React, TipTap, ProseMirror, docx, mammoth (BSD-2), html2pdf.js, idb-keyval, Tauri, Capacitor. Please re-check `npm ls`/`cargo` licenses before commercial distribution. Not affiliated with or derived from Microsoft products.
