import { createStore, get, set, del, values } from "idb-keyval";
import type { Doc } from "../types";
const store = createStore("bdword", "docs");
export const saveDoc = (d: Doc) => set(d.id, d, store);
export const getDoc = (id: string) => get<Doc>(id, store);
export const purgeDoc = (id: string) => del(id, store);
export const listDocs = async (): Promise<Doc[]> => (await values<Doc>(store)).sort((a, b) => b.updated - a.updated);
export const uid = () => (crypto as any).randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36);
