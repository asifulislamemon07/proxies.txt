export interface Source { id: string; author: string; title: string; year: string }
export interface Meta {
  pageSize: string; landscape: boolean;
  margin: { t: number; r: number; b: number; l: number }; // millimetres
  columns: number; pageColor: string; header: string; footer: string;
  pageNumbers: boolean; pageNumPos: "left" | "center" | "right";
  language: string; spellcheck: boolean; readOnly: boolean; sources: Source[];
}
export interface Doc { id: string; title: string; html: string; meta: Meta; created: number; updated: number; deleted?: number }
export const PAGE_SIZES: Record<string, [number, number]> = {
  A4: [210, 297], A3: [297, 420], A5: [148, 210], B5: [176, 250], Letter: [215.9, 279.4], Legal: [215.9, 355.6],
};
export const defaultMeta = (): Meta => ({
  pageSize: "A4", landscape: false, margin: { t: 25.4, r: 25.4, b: 25.4, l: 25.4 }, columns: 1,
  pageColor: "#ffffff", header: "", footer: "", pageNumbers: true, pageNumPos: "center",
  language: "en", spellcheck: true, readOnly: false, sources: [],
});
export const pageMm = (m: Meta): [number, number] => {
  const [w, h] = PAGE_SIZES[m.pageSize] || PAGE_SIZES.A4;
  return m.landscape ? [h, w] : [w, h];
};
export const MM_PX = 96 / 25.4;
