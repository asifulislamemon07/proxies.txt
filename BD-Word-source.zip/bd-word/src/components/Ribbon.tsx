import { ReactNode, useState } from "react";
import type { Editor } from "@tiptap/react";
import { Meta, PAGE_SIZES } from "../types";
import { uid } from "../storage/db";
import { pickFile } from "../import-export/platform";

export interface Api {
  meta: Meta; setMeta: (p: Partial<Meta>) => void;
  zoom: number; setZoom: (z: number) => void; fit: (m: "width" | "page") => void;
  dark: boolean; setDark: (b: boolean) => void; nav: boolean; setNav: (b: boolean) => void;
  marks: boolean; setMarks: (b: boolean) => void; view: "print" | "draft" | "read"; setView: (v: "print" | "draft" | "read") => void;
  openFind: (replace: boolean) => void; print: () => void; fullscreen: () => void;
  ask: (title: string, initial?: string) => Promise<string | null>;
  info: (title: string, body: ReactNode) => void; notify: (s: string) => void;
}
const FONTS = ["Calibri", "Arial", "Times New Roman", "Cambria", "Georgia", "Verdana", "Tahoma", "Segoe UI", "Courier New", "Nirmala UI", "Kalpurush", "SolaimanLipi", "Noto Sans Bengali", "Vrinda"];
const SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72];
const SYMBOLS = ["©", "®", "™", "°", "±", "×", "÷", "≠", "≤", "≥", "∞", "√", "π", "Σ", "µ", "€", "£", "¥", "৳", "§", "¶", "•", "→", "←", "✓", "★", "½", "¼", "¾", "α", "β", "γ", "Ω"];

function Btn({ t, k, on, act, dis, children }: { t: string; k?: string; on: () => void; act?: boolean; dis?: boolean; children: ReactNode }) {
  return (
    <button className={"btn" + (act ? " on" : "")} title={k ? `${t} (${k})` : t} aria-label={t} aria-pressed={act} disabled={dis}
      onMouseDown={(e) => e.preventDefault()} onClick={on}>{children}</button>
  );
}
const G = ({ n, children }: { n: string; children: ReactNode }) => (
  <div className="group"><div className="gbody">{children}</div><div className="gname">{n}</div></div>
);
const Sel = ({ l, v, on, opts }: { l: string; v: string; on: (v: string) => void; opts: [string, string][] }) => (
  <select aria-label={l} title={l} value={v} onChange={(e) => on(e.target.value)}>{opts.map(([a, b]) => <option key={a} value={a}>{b}</option>)}</select>
);

function changeCase(ed: Editor, mode: string) {
  const { from, to, empty } = ed.state.selection; if (empty) return;
  const tr = ed.state.tr;
  ed.state.doc.nodesBetween(from, to, (node, pos) => {
    if (!node.isText) return;
    const a = Math.max(pos, from), b = Math.min(pos + node.nodeSize, to);
    const txt = node.text!.slice(a - pos, b - pos);
    let out = txt;
    if (mode === "upper") out = txt.toUpperCase();
    else if (mode === "lower") out = txt.toLowerCase();
    else if (mode === "title") out = txt.toLowerCase().replace(/(^|\s)(\S)/g, (_m, s, c) => s + c.toUpperCase());
    else if (mode === "sentence") out = txt.toLowerCase().replace(/(^\s*|[.!?]\s+)(\S)/g, (_m, s, c) => s + c.toUpperCase());
    if (out !== txt && out.length === txt.length) tr.replaceWith(a, b, ed.schema.text(out, node.marks));
  });
  ed.view.dispatch(tr);
}

export function Ribbon({ tab, ed, api }: { tab: string; ed: Editor; api: Api }) {
  const c = () => ed.chain().focus();
  const ts = ed.getAttributes("textStyle");
  const curSize = ts.fontSize ? String(parseFloat(ts.fontSize)) : "11";
  const inTable = ed.isActive("table");
  const [rc, setRc] = useState({ r: 3, c: 3 });
  const setSize = (n: number) => n > 0 && n < 400 && c().setFontSize(`${n}pt`).run();
  const stepSize = (d: 1 | -1) => {
    const cur = parseFloat(curSize); const next = d > 0 ? SIZES.find((s) => s > cur) : [...SIZES].reverse().find((s) => s < cur);
    if (next) setSize(next);
  };
  const styleVal = ed.isActive("heading") ? "h" + ed.getAttributes("heading").level : ed.isActive("blockquote") ? "quote" : ed.getAttributes("paragraph").pstyle || "p";
  const applyStyle = (v: string) => {
    const ch = c();
    if (ed.isActive("blockquote") && v !== "quote") ch.lift("blockquote");
    if (v.startsWith("h")) ch.setHeading({ level: +v[1] as any }).updateAttributes("heading", { pstyle: null }).run();
    else if (v === "quote") { if (!ed.isActive("blockquote")) ch.setParagraph().toggleBlockquote().run(); }
    else ch.setParagraph().updateAttributes("paragraph", { pstyle: v === "p" ? null : v }).run();
  };
  const para = (attrs: Record<string, any>) => c().updateAttributes("paragraph", attrs).updateAttributes("heading", attrs).run();
  const indent = (d: number) => {
    if (ed.isActive("listItem")) { d > 0 ? c().sinkListItem("listItem").run() : c().liftListItem("listItem").run(); return; }
    const t = ed.isActive("heading") ? "heading" : "paragraph";
    const cur = parseFloat(ed.getAttributes(t).marginLeft || "0");
    para({ marginLeft: Math.max(0, cur + d * 36) ? `${Math.max(0, cur + d * 36)}px` : null });
  };
  const addImage = async () => {
    const f = await pickFile("image/*"); if (!f) return;
    const r = new FileReader(); r.onload = () => c().setImage({ src: String(r.result), alt: f.name } as any).run(); r.readAsDataURL(f);
  };
  const setLink = async () => {
    const prev = ed.getAttributes("link").href || "https://";
    const u = await api.ask("Hyperlink address", prev); if (u === null) return;
    u.trim() ? c().extendMarkRange("link").setLink({ href: u.trim() }).run() : c().unsetLink().run();
  };
  const headings = () => {
    const out: { level: number; text: string }[] = [];
    ed.state.doc.descendants((n) => { if (n.type.name === "heading") out.push({ level: n.attrs.level, text: n.textContent }); });
    return out;
  };
  const updateToc = () => {
    const items = headings(); const tr = ed.state.tr; let n = 0;
    ed.state.doc.descendants((node, pos) => { if (node.type.name === "toc") { tr.setNodeMarkup(pos, undefined, { items }); n++; } });
    if (n) { ed.view.dispatch(tr); api.notify(`Updated ${n} table of contents.`); } else api.notify("No table of contents in this document. Use Insert table of contents first.");
  };
  const addSource = async () => {
    const author = await api.ask("Author (e.g. Rahman, A.)"); if (!author) return;
    const title = await api.ask("Title"); if (!title) return;
    const year = (await api.ask("Year", "")) || "n.d.";
    api.setMeta({ sources: [...api.meta.sources, { id: uid(), author, title, year }] });
  };
  const a11y = () => {
    const issues: string[] = []; let last = 0;
    ed.state.doc.descendants((n) => {
      if (n.type.name === "image" && !n.attrs.alt) issues.push("An image has no alternative text.");
      if (n.type.name === "heading") {
        if (!n.textContent.trim()) issues.push("There is an empty heading.");
        if (last && n.attrs.level > last + 1) issues.push(`Heading level skips from ${last} to ${n.attrs.level}: “${n.textContent.slice(0, 40)}”.`);
        last = n.attrs.level;
      }
    });
    api.info("Accessibility check", issues.length ? <ul>{issues.map((x, i) => <li key={i}>{x}</li>)}</ul> : "No issues found by the built-in checks (images without alt text, empty headings, skipped heading levels).");
  };
  const stats = () => {
    const s = ed.storage.characterCount; const paras: number[] = []; ed.state.doc.descendants((n) => { if (n.type.name === "paragraph" && n.textContent.trim()) paras.push(1); });
    const sel = ed.state.selection; const selText = ed.state.doc.textBetween(sel.from, sel.to, " ");
    api.info("Word count", <div>Words: {s.words()}<br />Characters (with spaces): {s.characters()}<br />Paragraphs: {paras.length}{selText ? <><br />Selected words: {selText.trim().split(/\s+/).filter(Boolean).length}</> : null}</div>);
  };
  const m = api.meta;
  const margins = (v: string) => {
    const t: Record<string, number> = { normal: 25.4, narrow: 12.7, moderate: 19.1, wide: 50.8 };
    const x = t[v]; if (x) api.setMeta({ margin: { t: x, b: x, l: x, r: x } });
  };

  return (
    <div className="ribbon" role="toolbar" aria-label={tab + " tools"}>
      {tab === "Home" && <>
        <G n="Undo"><Btn t="Undo" k="Ctrl+Z" on={() => c().undo().run()} dis={!ed.can().undo()}>↶</Btn><Btn t="Redo" k="Ctrl+Y" on={() => c().redo().run()} dis={!ed.can().redo()}>↷</Btn></G>
        <G n="Clipboard">
          <Btn t="Cut" k="Ctrl+X" on={() => document.execCommand("cut")}>✂</Btn>
          <Btn t="Copy" k="Ctrl+C" on={() => document.execCommand("copy")}>⧉</Btn>
          <Btn t="Paste as plain text" on={async () => { try { c().insertContent(await navigator.clipboard.readText()).run(); } catch { api.notify("Clipboard blocked — press Ctrl+Shift+V."); } }}>Paste plain</Btn>
          <Btn t="Select all" k="Ctrl+A" on={() => c().selectAll().run()}>All</Btn>
          <Btn t="Duplicate selection" on={() => { const { from, to, empty } = ed.state.selection; if (!empty) ed.chain().focus().insertContentAt(to, ed.state.doc.slice(from, to).content.toJSON()).run(); }}>Dup</Btn>
          <Btn t="Find" k="Ctrl+F" on={() => api.openFind(false)}>Find</Btn><Btn t="Replace" k="Ctrl+H" on={() => api.openFind(true)}>Replace</Btn>
        </G>
        <G n="Font">
          <Sel l="Font family" v={ts.fontFamily || ""} on={(v) => (v ? c().setFontFamily(v).run() : c().unsetFontFamily().run())} opts={[["", "Default"], ...FONTS.map((f) => [f, f] as [string, string])]} />
          <input className="size" aria-label="Font size" list="sizes" key={curSize} defaultValue={curSize} onChange={(e) => setSize(+e.target.value)} />
          <datalist id="sizes">{SIZES.map((s) => <option key={s} value={s} />)}</datalist>
          <Btn t="Increase font size" on={() => stepSize(1)}>A⁺</Btn><Btn t="Decrease font size" on={() => stepSize(-1)}>A⁻</Btn>
          <Btn t="Bold" k="Ctrl+B" act={ed.isActive("bold")} on={() => c().toggleBold().run()}><b>B</b></Btn>
          <Btn t="Italic" k="Ctrl+I" act={ed.isActive("italic")} on={() => c().toggleItalic().run()}><i>I</i></Btn>
          <Btn t="Underline" k="Ctrl+U" act={ed.isActive("underline")} on={() => c().toggleUnderline().run()}><u>U</u></Btn>
          <Btn t="Strikethrough" act={ed.isActive("strike")} on={() => c().toggleStrike().run()}><s>S</s></Btn>
          <Btn t="Subscript" act={ed.isActive("subscript")} on={() => c().toggleSubscript().run()}>x₂</Btn>
          <Btn t="Superscript" act={ed.isActive("superscript")} on={() => c().toggleSuperscript().run()}>x²</Btn>
          <label className="clr" title="Text color">A<input type="color" aria-label="Text color" value={ts.color || "#000000"} onChange={(e) => c().setColor(e.target.value).run()} /></label>
          <label className="clr hl" title="Highlight color">▮<input type="color" aria-label="Highlight color" defaultValue="#ffff00" onChange={(e) => c().setHighlight({ color: e.target.value }).run()} /></label>
          <Btn t="Remove highlight" on={() => c().unsetHighlight().run()}>✕▮</Btn>
          <Btn t="Clear formatting" on={() => c().unsetAllMarks().clearNodes().run()}>Clear</Btn>
          <Sel l="Change case" v="" on={(v) => v && changeCase(ed, v)} opts={[["", "Aa case"], ["upper", "UPPERCASE"], ["lower", "lowercase"], ["title", "Title Case"], ["sentence", "Sentence case"]]} />
        </G>
        <G n="Paragraph">
          {(["left", "center", "right", "justify"] as const).map((a) => <Btn key={a} t={"Align " + a} act={ed.isActive({ textAlign: a })} on={() => c().setTextAlign(a).run()}>{{ left: "⇤", center: "↔", right: "⇥", justify: "☰" }[a]}</Btn>)}
          <Btn t="Bulleted list" act={ed.isActive("bulletList")} on={() => c().toggleBulletList().run()}>• List</Btn>
          <Btn t="Numbered list" act={ed.isActive("orderedList")} on={() => c().toggleOrderedList().run()}>1. List</Btn>
          <Btn t="Increase indent (nest list item)" on={() => indent(1)}>→|</Btn><Btn t="Decrease indent" on={() => indent(-1)}>|←</Btn>
          <Sel l="Line spacing" v="" on={(v) => v && para({ lineHeight: v === "1" ? null : v })} opts={[["", "Spacing"], ["1", "1.0"], ["1.15", "1.15"], ["1.5", "1.5"], ["2", "2.0"], ["2.5", "2.5"]]} />
          <Sel l="Space before" v="" on={(v) => v && para({ marginTop: v === "0" ? null : v + "px" })} opts={[["", "Before"], ["0", "0"], ["6", "6 pt"], ["12", "12 pt"], ["24", "24 pt"]]} />
          <Sel l="Space after" v="" on={(v) => v && para({ marginBottom: v === "0" ? null : v + "px" })} opts={[["", "After"], ["0", "0"], ["6", "6 pt"], ["12", "12 pt"], ["24", "24 pt"]]} />
          <Btn t="Show/hide formatting marks" act={api.marks} on={() => api.setMarks(!api.marks)}>¶</Btn>
        </G>
        <G n="Styles"><Sel l="Paragraph style" v={styleVal} on={applyStyle} opts={[["p", "Normal"], ["title", "Title"], ["subtitle", "Subtitle"], ["h1", "Heading 1"], ["h2", "Heading 2"], ["h3", "Heading 3"], ["h4", "Heading 4"], ["h5", "Heading 5"], ["h6", "Heading 6"], ["quote", "Quote"], ["caption", "Caption"]]} /></G>
      </>}

      {tab === "Insert" && <>
        <G n="Pages"><Btn t="Page break" k="Ctrl+Enter" on={() => c().insertPageBreak().run()}>Page break</Btn><Btn t="Blank page" on={() => c().insertPageBreak().insertPageBreak().run()}>Blank page</Btn><Btn t="Horizontal line" on={() => c().setHorizontalRule().run()}>― Line</Btn></G>
        <G n="Tables">
          <label>Rows <input className="num" type="number" min={1} max={50} value={rc.r} onChange={(e) => setRc({ ...rc, r: +e.target.value })} /></label>
          <label>Cols <input className="num" type="number" min={1} max={20} value={rc.c} onChange={(e) => setRc({ ...rc, c: +e.target.value })} /></label>
          <Btn t="Insert table" on={() => c().insertTable({ rows: Math.max(1, rc.r), cols: Math.max(1, rc.c), withHeaderRow: true }).run()}>⊞ Table</Btn>
          <Btn t="Add row below" dis={!inTable} on={() => c().addRowAfter().run()}>+Row</Btn><Btn t="Delete row" dis={!inTable} on={() => c().deleteRow().run()}>−Row</Btn>
          <Btn t="Add column right" dis={!inTable} on={() => c().addColumnAfter().run()}>+Col</Btn><Btn t="Delete column" dis={!inTable} on={() => c().deleteColumn().run()}>−Col</Btn>
          <Btn t="Merge cells" dis={!inTable} on={() => c().mergeCells().run()}>Merge</Btn><Btn t="Split cell" dis={!inTable} on={() => c().splitCell().run()}>Split</Btn>
          <Btn t="Toggle header row" dis={!inTable} on={() => c().toggleHeaderRow().run()}>Header row</Btn>
          <label className="clr" title="Cell shading">▨<input type="color" aria-label="Cell shading" disabled={!inTable} defaultValue="#dde6f5" onChange={(e) => c().setCellAttribute("backgroundColor", e.target.value).run()} /></label>
          <Btn t="Delete table" dis={!inTable} on={() => c().deleteTable().run()}>Del table</Btn>
        </G>
        <G n="Images">
          <Btn t="Insert image from device" on={addImage}>🖼 Image</Btn>
          {ed.isActive("image") && <>
            <label>Width px <input className="num" type="number" min={20} max={1200} defaultValue={ed.getAttributes("image").width || ""} key={ed.getAttributes("image").width} onChange={(e) => c().updateAttributes("image", { width: e.target.value || null }).run()} /></label>
            {(["left", "center", "right"] as const).map((a) => <Btn key={a} t={"Align image " + a} act={ed.getAttributes("image").align === a} on={() => c().updateAttributes("image", { align: a }).run()}>{a[0].toUpperCase()}</Btn>)}
            <Btn t="Alternative text" on={async () => { const v = await api.ask("Alternative text", ed.getAttributes("image").alt || ""); if (v !== null) c().updateAttributes("image", { alt: v }).run(); }}>Alt text</Btn>
            <Btn t="Delete image" on={() => c().deleteSelection().run()}>Delete</Btn>
          </>}
        </G>
        <G n="Links & text">
          <Btn t="Hyperlink" k="Ctrl+K" act={ed.isActive("link")} on={setLink}>🔗 Link</Btn>
          <Btn t="Date and time" on={() => c().insertContent(new Date().toLocaleString()).run()}>Date/time</Btn>
          <Sel l="Symbol" v="" on={(v) => v && c().insertContent(v).run()} opts={[["", "Ω Symbol"], ...SYMBOLS.map((s) => [s, s] as [string, string])]} />
          <Btn t="Insert table of contents" on={() => c().insertToc(headings()).run()}>Contents</Btn>
        </G>
        <G n="Header & footer">
          <Btn t="Edit header text" on={async () => { const v = await api.ask("Header text (printed on every page)", m.header); if (v !== null) api.setMeta({ header: v }); }}>Header</Btn>
          <Btn t="Edit footer text" on={async () => { const v = await api.ask("Footer text (printed on every page)", m.footer); if (v !== null) api.setMeta({ footer: v }); }}>Footer</Btn>
          <Btn t="Page numbers" act={m.pageNumbers} on={() => api.setMeta({ pageNumbers: !m.pageNumbers })}>Page #</Btn>
        </G>
      </>}

      {tab === "Layout" && <>
        <G n="Page setup">
          <Sel l="Page size" v={m.pageSize} on={(v) => api.setMeta({ pageSize: v })} opts={Object.keys(PAGE_SIZES).map((k) => [k, `${k} (${PAGE_SIZES[k][0]}×${PAGE_SIZES[k][1]} mm)`])} />
          <Sel l="Orientation" v={m.landscape ? "l" : "p"} on={(v) => api.setMeta({ landscape: v === "l" })} opts={[["p", "Portrait"], ["l", "Landscape"]]} />
          <Sel l="Margin preset" v="" on={margins} opts={[["", "Margins…"], ["normal", "Normal 2.54 cm"], ["narrow", "Narrow 1.27 cm"], ["moderate", "Moderate 1.91 cm"], ["wide", "Wide 5.08 cm"]]} />
          {(["t", "b", "l", "r"] as const).map((k) => (
            <label key={k}>{{ t: "Top", b: "Bottom", l: "Left", r: "Right" }[k]} mm <input className="num" type="number" min={0} max={100} step={0.5} value={m.margin[k]} onChange={(e) => api.setMeta({ margin: { ...m.margin, [k]: Math.max(0, +e.target.value) } })} /></label>
          ))}
        </G>
        <G n="Columns & color">
          <Sel l="Columns" v={String(m.columns)} on={(v) => api.setMeta({ columns: +v })} opts={[["1", "1 column"], ["2", "2 columns"], ["3", "3 columns"]]} />
          <label className="clr" title="Page color">▭<input type="color" aria-label="Page color" value={m.pageColor} onChange={(e) => api.setMeta({ pageColor: e.target.value })} /></label>
          <Btn t="Reset page color" on={() => api.setMeta({ pageColor: "#ffffff" })}>Reset color</Btn>
        </G>
        <G n="Page numbers"><Btn t="Page numbers" act={m.pageNumbers} on={() => api.setMeta({ pageNumbers: !m.pageNumbers })}>Show</Btn>
          <Sel l="Page number position" v={m.pageNumPos} on={(v) => api.setMeta({ pageNumPos: v as any })} opts={[["left", "Left"], ["center", "Center"], ["right", "Right"]]} /></G>
        <G n="Breaks"><Btn t="Page break" on={() => c().insertPageBreak().run()}>Page break</Btn><Btn t="Print preview" on={api.print}>Print preview</Btn></G>
      </>}

      {tab === "References" && <>
        <G n="Table of contents"><Btn t="Insert table of contents" on={() => c().insertToc(headings()).run()}>Insert TOC</Btn><Btn t="Update table of contents" on={updateToc}>Update TOC</Btn></G>
        <G n="Citations & bibliography">
          <Btn t="Add source" on={addSource}>Add source</Btn>
          <Sel l="Insert citation" v="" on={(v) => { const s = m.sources.find((x) => x.id === v); if (s) c().insertContent(`(${s.author.split(",")[0]}, ${s.year})`).run(); }} opts={[["", `Cite (${m.sources.length})`], ...m.sources.map((s) => [s.id, `${s.author} ${s.year}`] as [string, string])]} />
          <Btn t="Insert bibliography" dis={!m.sources.length} on={() => c().insertContent(`<h2>Bibliography</h2>` + [...m.sources].sort((a, b) => a.author.localeCompare(b.author)).map((s) => `<p>${s.author} (${s.year}). <em>${s.title}</em>.</p>`).join("")).run()}>Bibliography</Btn>
          <Btn t="Manage sources" on={() => api.info("Sources", m.sources.length ? <ul>{m.sources.map((s) => <li key={s.id}>{s.author} ({s.year}) — {s.title} <button onClick={() => api.setMeta({ sources: m.sources.filter((x) => x.id !== s.id) })}>Remove</button></li>)}</ul> : "No sources yet.")}>Sources</Btn>
        </G>
        <G n="Not yet available"><span className="muted">Footnotes, endnotes, cross-references and index are planned (not implemented).</span></G>
      </>}

      {tab === "Review" && <>
        <G n="Proofing">
          <Btn t="Spell check (browser engine) on/off" act={m.spellcheck} on={() => api.setMeta({ spellcheck: !m.spellcheck })}>Spelling</Btn>
          <Sel l="Language" v={m.language} on={(v) => api.setMeta({ language: v })} opts={[["en", "English"], ["en-GB", "English (UK)"], ["bn", "Bangla (বাংলা)"]]} />
          <Btn t="Word count" on={stats}>Word count</Btn>
        </G>
        <G n="Protect"><Btn t="Read-only mode" act={m.readOnly} on={() => api.setMeta({ readOnly: !m.readOnly })}>{m.readOnly ? "🔒 Read-only" : "Read-only"}</Btn></G>
        <G n="Accessibility"><Btn t="Accessibility check" on={a11y}>Check</Btn></G>
        <G n="Not yet available"><span className="muted">Comments, track changes, compare and grammar check are planned (not implemented).</span></G>
      </>}

      {tab === "View" && <>
        <G n="Views"><Sel l="View mode" v={api.view} on={(v) => api.setView(v as any)} opts={[["print", "Print layout"], ["draft", "Draft"], ["read", "Read mode"]]} /></G>
        <G n="Zoom">
          <Btn t="Zoom out" on={() => api.setZoom(Math.max(0.25, +(api.zoom - 0.1).toFixed(2)))}>−</Btn><span className="zl">{Math.round(api.zoom * 100)}%</span>
          <Btn t="Zoom in" on={() => api.setZoom(Math.min(3, +(api.zoom + 0.1).toFixed(2)))}>+</Btn>
          <Btn t="100%" on={() => api.setZoom(1)}>100%</Btn><Btn t="Fit page width" on={() => api.fit("width")}>Fit width</Btn><Btn t="Fit whole page" on={() => api.fit("page")}>Fit page</Btn>
        </G>
        <G n="Show"><Btn t="Navigation pane" act={api.nav} on={() => api.setNav(!api.nav)}>Navigation</Btn><Btn t="Formatting marks" act={api.marks} on={() => api.setMarks(!api.marks)}>¶ Marks</Btn></G>
        <G n="Window"><Btn t="Full screen" k="F11" on={api.fullscreen}>Full screen</Btn><Btn t="Dark mode" act={api.dark} on={() => api.setDark(!api.dark)}>🌙 Dark</Btn></G>
      </>}

      {tab === "Help" && <>
        <G n="Help"><Btn t="Keyboard shortcuts" on={() => api.info("Keyboard shortcuts", <pre>{"Ctrl+N New\nCtrl+O Open file\nCtrl+S Save\nCtrl+Shift+S Rename / Save as\nCtrl+P Print\nCtrl+F Find   Ctrl+H Replace\nCtrl+B/I/U Bold/Italic/Underline\nCtrl+Z Undo   Ctrl+Y Redo\nCtrl+A Select all\nCtrl+K Link"}</pre>)}>Shortcuts</Btn>
          <Btn t="About BD Word" on={() => api.info("About BD Word", "BD Word 1.0.0 — a free, offline word processor. Open-source components: React, TipTap/ProseMirror, mammoth, docx, html2pdf.js (MIT/BSD-style licenses). Not affiliated with Microsoft.")}>About</Btn></G>
      </>}
    </div>
  );
}
