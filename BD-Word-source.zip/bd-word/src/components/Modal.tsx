import { ReactNode, useState } from "react";
export interface ModalState {
  title: string; body?: ReactNode; input?: string; ok?: string; cancel?: boolean;
  resolve: (v: string | boolean | null) => void;
}
export function Modal({ m, close }: { m: ModalState; close: () => void }) {
  const [v, setV] = useState(m.input ?? "");
  const done = (r: string | boolean | null) => { m.resolve(r); close(); };
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label={m.title} onKeyDown={(e) => e.key === "Escape" && done(null)}>
      <div className="modal">
        <h3>{m.title}</h3>
        {m.body && <div className="mbody">{m.body}</div>}
        {m.input !== undefined && (
          <input autoFocus value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && done(v)} />
        )}
        <div className="mbtns">
          {m.cancel !== false && <button onClick={() => done(m.input !== undefined ? null : false)}>Cancel</button>}
          <button className="primary" onClick={() => done(m.input !== undefined ? v : true)}>{m.ok || "OK"}</button>
        </div>
      </div>
    </div>
  );
}
