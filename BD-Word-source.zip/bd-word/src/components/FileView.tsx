import { useState } from "react";
import type { Doc } from "../types";
import { TEMPLATES } from "../templates";

export interface FileApi {
  docs: Doc[]; cur: Doc | null; close: () => void;
  newBlank: () => void; fromTemplate: (id: string) => void; openDoc: (d: Doc) => void;
  openFile: () => void; save: () => void; rename: (d?: Doc) => void; duplicate: (d?: Doc) => void; trash: (d: Doc) => void;
  restore: (d: Doc) => void; purge: (d: Doc) => void; saveCopy: () => void;
  exportDocx: () => void; exportPdf: () => void; exportTxt: () => void; exportHtml: () => void;
  print: () => void; backup: () => void; restoreBackup: () => void; props: () => void; closeDoc: () => void;
}
const SECS = ["New", "Open", "Save & Export", "Recently deleted", "Backup", "Properties"] as const;

export function FileView({ a }: { a: FileApi }) {
  const [sec, setSec] = useState<(typeof SECS)[number]>("New");
  const live = a.docs.filter((d) => !d.deleted);
  const dead = a.docs.filter((d) => d.deleted);
  const groups = [...new Set(TEMPLATES.map((t) => t.group))];
  return (
    <div className="fileview">
      <aside>
        <button className="back" onClick={a.close}>← Back to document</button>
        {SECS.map((s) => <button key={s} className={s === sec ? "on" : ""} onClick={() => setSec(s)}>{s}</button>)}
        <button onClick={a.print}>Print</button>
        <button onClick={a.closeDoc}>Close document</button>
      </aside>
      <section>
        {sec === "New" && <>
          <h2>New</h2><button className="primary" onClick={a.newBlank}>＋ Blank document (Ctrl+N)</button>
          {groups.map((g) => <div key={g}><h3>{g}</h3><div className="cards">{TEMPLATES.filter((t) => t.group === g).map((t) => (
            <button key={t.id} className="card" onClick={() => a.fromTemplate(t.id)}><div className="thumb" dangerouslySetInnerHTML={{ __html: t.html }} />{t.name}</button>))}</div></div>)}
        </>}
        {sec === "Open" && <>
          <h2>Open</h2>
          <button className="primary" onClick={a.openFile}>Open file from device… (.docx, .txt, .html)</button>
          <h3>Recent documents</h3>
          {!live.length && <p className="muted">No documents yet.</p>}
          <ul className="doclist">{live.map((d) => (
            <li key={d.id}><button className="link" onClick={() => a.openDoc(d)}>{d.title}</button><span className="muted">{new Date(d.updated).toLocaleString()}</span>
              <button onClick={() => a.rename(d)}>Rename</button><button onClick={() => a.duplicate(d)}>Duplicate</button><button onClick={() => a.trash(d)}>Delete</button></li>))}</ul>
        </>}
        {sec === "Save & Export" && <>
          <h2>Save & Export</h2>
          <p className="muted">BD Word saves automatically to this device. Use these to create files you can share or keep elsewhere.</p>
          <div className="cards big">
            <button onClick={a.save}>Save now<small>Ctrl+S</small></button>
            <button onClick={() => a.rename()}>Rename / Save As<small>Ctrl+Shift+S</small></button>
            <button onClick={a.saveCopy}>Save a copy<small>new library document</small></button>
            <button onClick={a.exportDocx}>Export DOCX<small>editable Word format</small></button>
            <button onClick={a.exportPdf}>Export PDF<small>image-based pages</small></button>
            <button onClick={a.exportTxt}>Export TXT<small>plain text</small></button>
            <button onClick={a.exportHtml}>Export HTML<small>web page</small></button>
          </div>
        </>}
        {sec === "Recently deleted" && <>
          <h2>Recently deleted</h2>
          {!dead.length && <p className="muted">Nothing here.</p>}
          <ul className="doclist">{dead.map((d) => (
            <li key={d.id}><span>{d.title}</span><span className="muted">deleted {new Date(d.deleted!).toLocaleString()}</span>
              <button onClick={() => a.restore(d)}>Restore</button><button onClick={() => a.purge(d)}>Delete forever</button></li>))}</ul>
        </>}
        {sec === "Backup" && <>
          <h2>Backup & restore</h2>
          <p>Your documents live only on this device. Create a backup file regularly and keep it somewhere safe (USB drive, another device). Uninstalling the app or clearing app data on Android erases local documents.</p>
          <button className="primary" onClick={a.backup}>Create backup of all documents</button> <button onClick={a.restoreBackup}>Restore from backup…</button>
        </>}
        {sec === "Properties" && a.cur && <>
          <h2>Document properties</h2>
          <table className="props"><tbody>
            <tr><td>Title</td><td>{a.cur.title}</td></tr><tr><td>Created</td><td>{new Date(a.cur.created).toLocaleString()}</td></tr>
            <tr><td>Last saved</td><td>{new Date(a.cur.updated).toLocaleString()}</td></tr><tr><td>Page</td><td>{a.cur.meta.pageSize} {a.cur.meta.landscape ? "landscape" : "portrait"}</td></tr>
            <tr><td>Language</td><td>{a.cur.meta.language}</td></tr><tr><td>ID</td><td>{a.cur.id}</td></tr></tbody></table>
          <button onClick={a.props}>Word count…</button>
        </>}
      </section>
    </div>
  );
}
