import { useEffect, useState } from "react";
import type { Editor } from "@tiptap/react";
import { findMatches, searchKey } from "../editor/extensions";

export function FindBar({ ed, replace, onClose }: { ed: Editor; replace: boolean; onClose: () => void }) {
  const [term, setTerm] = useState("");
  const [rep, setRep] = useState("");
  const [idx, setIdx] = useState(-1);
  const matches = () => findMatches(ed.state.doc, term);
  const setTermMeta = (t: string) => ed.view.dispatch(ed.state.tr.setMeta(searchKey, { term: t }));
  useEffect(() => { setTermMeta(term); setIdx(-1); }, [term]);
  useEffect(() => () => { setTermMeta(""); }, []);
  const go = (dir: 1 | -1) => {
    const m = matches(); if (!m.length) return;
    const n = (idx + dir + m.length) % m.length; setIdx(n);
    ed.chain().focus().setTextSelection(m[n]).scrollIntoView().run();
  };
  const replaceOne = () => {
    const m = matches(); if (!m.length) return;
    const sel = ed.state.selection;
    const cur = m.find((x) => x.from === sel.from && x.to === sel.to) || m[Math.max(idx, 0)];
    ed.view.dispatch(ed.state.tr.insertText(rep, cur.from, cur.to));
    setTimeout(() => go(1), 0);
  };
  const replaceAll = () => {
    const m = matches().reverse(); if (!m.length) return;
    const tr = ed.state.tr; m.forEach((x) => tr.insertText(rep, x.from, x.to)); ed.view.dispatch(tr);
  };
  const count = term ? matches().length : 0;
  return (
    <div className="findbar" role="search">
      <input autoFocus placeholder="Find" aria-label="Find" value={term} onChange={(e) => setTerm(e.target.value)} onKeyDown={(e) => e.key === "Enter" && go(e.shiftKey ? -1 : 1)} />
      {replace && <input placeholder="Replace with" aria-label="Replace with" value={rep} onChange={(e) => setRep(e.target.value)} />}
      <span className="count">{count} found</span>
      <button onClick={() => go(-1)} title="Previous">↑</button>
      <button onClick={() => go(1)} title="Next">↓</button>
      {replace && <><button onClick={replaceOne}>Replace</button><button onClick={replaceAll}>Replace all</button></>}
      <button onClick={onClose} aria-label="Close find">✕</button>
    </div>
  );
}
