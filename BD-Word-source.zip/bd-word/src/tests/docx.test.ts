import { describe, it, expect } from "vitest";
import { Packer } from "docx";
import JSZip from "jszip";
import mammoth from "mammoth";
import { buildDocx } from "../import-export/docxExport";
import { defaultMeta } from "../types";
import { textToHtml } from "../import-export/textio";

const sample: any = { type: "doc", content: [
  { type: "heading", attrs: { level: 1 }, content: [{ type: "text", text: "Report Title" }] },
  { type: "paragraph", content: [{ type: "text", text: "বাংলা লেখা — আমার সোনার বাংলা", marks: [{ type: "bold" }] }] },
  { type: "bulletList", content: [{ type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "item one" }] }] }] },
  { type: "table", content: [{ type: "tableRow", content: [
    { type: "tableHeader", attrs: { colspan: 1, rowspan: 1 }, content: [{ type: "paragraph", content: [{ type: "text", text: "H1" }] }] },
    { type: "tableCell", attrs: { colspan: 1, rowspan: 1, backgroundColor: "#dde6f5" }, content: [{ type: "paragraph", content: [{ type: "text", text: "C1" }] }] }] }] },
  { type: "paragraph", content: [{ type: "text", text: "link", marks: [{ type: "link", attrs: { href: "https://example.com" } }] }] },
] };

describe("DOCX export", () => {
  it("creates a valid zip containing Bangla text, headings, table", async () => {
    const { doc } = await buildDocx(sample, defaultMeta(), "t");
    const buf = await Packer.toBuffer(doc);
    const zip = await JSZip.loadAsync(buf);
    const xml = await zip.file("word/document.xml")!.async("string");
    expect(xml).toContain("আমার সোনার বাংলা");
    expect(xml).toContain("Heading1");
    expect(xml).toContain("<w:tbl>");
  });
  it("round-trips through mammoth (export → re-import)", async () => {
    const { doc } = await buildDocx(sample, defaultMeta(), "t");
    const buffer = await Packer.toBuffer(doc);
    const r = await mammoth.convertToHtml({ buffer });
    expect(r.value).toContain("Report Title");
    expect(r.value).toContain("আমার সোনার বাংলা");
    expect(r.value).toContain("<table>");
  });
  it("handles an empty document and a large document", async () => {
    await buildDocx({ type: "doc", content: [] }, defaultMeta(), "e");
    const big = { type: "doc", content: Array.from({ length: 3000 }, (_, i) => ({ type: "paragraph", content: [{ type: "text", text: "Paragraph " + i }] })) };
    const t = Date.now(); const { doc } = await buildDocx(big as any, defaultMeta(), "big");
    expect((await Packer.toBuffer(doc)).length).toBeGreaterThan(1000);
    expect(Date.now() - t).toBeLessThan(30000);
  });
  it("rejects a corrupted docx on import", async () => {
    await expect(mammoth.convertToHtml({ buffer: Buffer.from("not a docx") })).rejects.toBeTruthy();
  });
});
describe("TXT", () => { it("escapes html", () => { expect(textToHtml("a<b\nc")).toBe("<p>a&lt;b</p><p>c</p>"); }); });
