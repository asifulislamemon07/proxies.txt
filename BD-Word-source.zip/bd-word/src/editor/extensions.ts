import { Extension, Node, mergeAttributes } from "@tiptap/core";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import TextAlign from "@tiptap/extension-text-align";
import TextStyle from "@tiptap/extension-text-style";
import Color from "@tiptap/extension-color";
import Highlight from "@tiptap/extension-highlight";
import FontFamily from "@tiptap/extension-font-family";
import Subscript from "@tiptap/extension-subscript";
import Superscript from "@tiptap/extension-superscript";
import Link from "@tiptap/extension-link";
import Image from "@tiptap/extension-image";
import Table from "@tiptap/extension-table";
import TableRow from "@tiptap/extension-table-row";
import TableCell from "@tiptap/extension-table-cell";
import TableHeader from "@tiptap/extension-table-header";
import CharacterCount from "@tiptap/extension-character-count";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import { Decoration, DecorationSet } from "@tiptap/pm/view";

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    fontSize: { setFontSize: (s: string) => ReturnType; unsetFontSize: () => ReturnType };
    pageBreak: { insertPageBreak: () => ReturnType };
    toc: { insertToc: (items: TocItem[]) => ReturnType };
  }
}
export interface TocItem { level: number; text: string }

export const FontSize = Extension.create({
  name: "fontSize",
  addGlobalAttributes() {
    return [{ types: ["textStyle"], attributes: { fontSize: {
      default: null,
      parseHTML: (el: HTMLElement) => el.style.fontSize || null,
      renderHTML: (a: any) => (a.fontSize ? { style: `font-size:${a.fontSize}` } : {}),
    } } }];
  },
  addCommands() {
    return {
      setFontSize: (s: string) => ({ chain }) => chain().setMark("textStyle", { fontSize: s }).run(),
      unsetFontSize: () => ({ chain }) => chain().setMark("textStyle", { fontSize: null }).removeEmptyTextStyle().run(),
    };
  },
});

const styleAttr = (name: string, css: string) => ({
  default: null,
  parseHTML: (el: HTMLElement) => (el.style as any)[name] || null,
  renderHTML: (a: any) => (a[name] ? { style: `${css}:${a[name]}` } : {}),
});
export const ParaFormat = Extension.create({
  name: "paraFormat",
  addGlobalAttributes() {
    return [{ types: ["paragraph", "heading"], attributes: {
      lineHeight: styleAttr("lineHeight", "line-height"),
      marginLeft: styleAttr("marginLeft", "margin-left"),
      marginTop: styleAttr("marginTop", "margin-top"),
      marginBottom: styleAttr("marginBottom", "margin-bottom"),
      pstyle: {
        default: null,
        parseHTML: (el: HTMLElement) => el.getAttribute("data-style"),
        renderHTML: (a: any) => (a.pstyle ? { "data-style": a.pstyle, class: `st-${a.pstyle}` } : {}),
      },
    } }];
  },
});

export const PageBreak = Node.create({
  name: "pageBreak", group: "block", atom: true, selectable: true,
  parseHTML() { return [{ tag: "div[data-page-break]" }]; },
  renderHTML() { return ["div", { "data-page-break": "", class: "page-break" }]; },
  addCommands() { return { insertPageBreak: () => ({ commands }) => commands.insertContent({ type: "pageBreak" }) }; },
});

export const Toc = Node.create({
  name: "toc", group: "block", atom: true, selectable: true,
  addAttributes() {
    return { items: {
      default: [],
      parseHTML: (el: HTMLElement) => { try { return JSON.parse(el.getAttribute("data-items") || "[]"); } catch { return []; } },
      renderHTML: (a: any) => ({ "data-items": JSON.stringify(a.items || []) }),
    } };
  },
  parseHTML() { return [{ tag: "div[data-toc]" }]; },
  renderHTML({ node, HTMLAttributes }) {
    const items: TocItem[] = node.attrs.items || [];
    return ["div", mergeAttributes(HTMLAttributes, { "data-toc": "", class: "toc" }),
      ["p", { class: "toc-title" }, "Table of Contents"],
      ...items.map((i) => ["p", { style: `margin-left:${(i.level - 1) * 18}px` }, i.text] as any)];
  },
  addCommands() { return { insertToc: (items: TocItem[]) => ({ commands }) => commands.insertContent({ type: "toc", attrs: { items } }) }; },
});

const bgAttr = {
  default: null,
  parseHTML: (el: HTMLElement) => el.style.backgroundColor || null,
  renderHTML: (a: any) => (a.backgroundColor ? { style: `background-color:${a.backgroundColor}` } : {}),
};
const Cell = TableCell.extend({ addAttributes() { return { ...this.parent?.(), backgroundColor: bgAttr }; } });
const Header = TableHeader.extend({ addAttributes() { return { ...this.parent?.(), backgroundColor: bgAttr }; } });

const BdImage = Image.configure({ allowBase64: true }).extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      width: { default: null, parseHTML: (el: HTMLElement) => el.getAttribute("width"), renderHTML: (a: any) => (a.width ? { width: a.width } : {}) },
      align: { default: "left", parseHTML: (el: HTMLElement) => el.getAttribute("data-align") || "left", renderHTML: (a: any) => ({ "data-align": a.align }) },
    };
  },
});

// ---- Find & replace (decoration plugin) ----
export const searchKey = new PluginKey<{ term: string }>("bdsearch");
export function findMatches(doc: any, term: string, cs = false) {
  const res: { from: number; to: number }[] = [];
  if (!term) return res;
  const t = cs ? term : term.toLowerCase();
  doc.descendants((node: any, pos: number) => {
    if (node.isText && node.text) {
      const s = cs ? node.text : node.text.toLowerCase();
      let i = 0;
      while ((i = s.indexOf(t, i)) >= 0) { res.push({ from: pos + i, to: pos + i + t.length }); i += t.length; }
    }
  });
  return res;
}
export const Search = Extension.create({
  name: "bdsearch",
  addProseMirrorPlugins() {
    return [new Plugin({
      key: searchKey,
      state: {
        init: () => ({ term: "" }),
        apply: (tr, old) => tr.getMeta(searchKey) ?? old,
      },
      props: {
        decorations(state) {
          const st = searchKey.getState(state);
          if (!st?.term) return null;
          const ds = findMatches(state.doc, st.term).map((m) => Decoration.inline(m.from, m.to, { class: "find-hit" }));
          return DecorationSet.create(state.doc, ds);
        },
      },
    })];
  },
});

export function buildExtensions() {
  return [
    StarterKit.configure({ heading: { levels: [1, 2, 3, 4, 5, 6] } }),
    Underline, TextStyle, FontSize, Color, FontFamily, Highlight.configure({ multicolor: true }),
    Subscript, Superscript, TextAlign.configure({ types: ["heading", "paragraph"] }),
    Link.configure({ openOnClick: false, autolink: true }),
    BdImage, Table.configure({ resizable: true }), TableRow, Cell, Header,
    CharacterCount, ParaFormat, PageBreak, Toc, Search,
  ];
}
