import { ReactNode, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import { buildExtensions } from "./editor/extensions";
import { Ribbon, Api } from "./components/Ribbon";
import { FindBar } from "./components/FindBar";
import { Modal, ModalState } from "./components/Modal";
import { FileView, FileApi } from "./components/FileView";
import { Doc, Meta, MM_PX, defaultMeta, pageMm } from "./types";
import { getDoc, listDocs, purgeDoc, saveDoc, uid } from "./storage/db";
import { TEMPLATES } from "./templates";
import { exportDocxBlob } from "./import-export/docxExport";
import { importDocx } from "./import-export/docxImport";
import { exportPdfBlob } from "./import-export/pdf";
import { textToHtml, wrapHtml } from "./import-export/textio";
import { isNative, pickFile, saveBlob } from "./import-export/platform";

const TABS = ["File", "Home", "Insert", "Layout", "References", "Review", "View", "Help"];

export default function App() {
  const [docs, setDocs] = useState<Doc[]>([]);
  const [cur, setCur] = useState<Doc | null>(null);
  const curRef = useRef<Doc | null>(null);
  const [dirty, setDirty] = useState(false);
  const [saveErr, setSaveErr] = useState(false);
  const [status, setStatus] = useState("Starting…");
  const [tab, setTab] = useState("Home");
  const [fileOpen, setFileOpen] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [dark, setDark] = useState(() => localStorage.getItem("bd:dark") === "1");
  const [nav, setNav] = useState(false);
  const [marks, setMarks] = useState(false);
  const [view, setView] = useState<"print" | "draft" | "read">("print");
  const [find, setFind] = useState<null | { replace: boolean }>(null);
  const [modal, setModal] = useState<ModalState | null>(null);
  const [pages, setPages] = useState({ total: 1, current: 1 });
  const loading = useRef(false);
  const timer = useRef<number>();
  const scrollRef = useRef<HTMLDivElement>(null);
  const sheetRef = useRef<HTMLDivElement>(null);
  const scheduleRef = useRef<() => void>(() => {});

  const editor = useEditor({
    extensions: buildExtensions(),
    content: "<p></p>",
    onUpdate: () => scheduleRef.current(),
  });

  // ---------- dialogs ----------
  const ask = (title: string, initial = "") => new Promise<string | null>((res) => setModal({ title, input: initial, resolve: res as any }));
  const confirm = (title: string, body: ReactNode, ok = "OK") => new Promise<boolean>((res) => setModal({ title, body, ok, resolve: res as any }));
  const info = (title: string, body: ReactNode) => setModal({ title, body, cancel: false, resolve: () => {} });
  const notify = (s: string) => { setStatus(s); };

  // ---------- persistence ----------
  const refresh = async () => setDocs(await listDocs());
  const persist = async (d: Doc) => {
    try {
      await saveDoc(d); setDirty(false); setSaveErr(false);
      setStatus("Saved " + new Date().toLocaleTimeString()); localStorage.setItem("bd:last", d.id); refresh();
      return true;
    } catch (e: any) {
      setSaveErr(true); setStatus("SAVE FAILED");
      info("Could not save", `Saving failed (${e?.message || e}). Your text is still open. Use File → Save & Export → Export DOCX to keep a copy, free some storage space, then try again.`);
      return false;
    }
  };
  const flush = useCallback(async () => {
    const c = curRef.current; if (!c || !editor || loading.current) return true;
    const d = { ...c, html: editor.getHTML(), updated: Date.now() };
    curRef.current = d; setCur(d); return persist(d);
  }, [editor]);
  scheduleRef.current = () => {
    if (loading.current || !curRef.current) return;
    setDirty(true); window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => flush(), 1200);
  };
  const load = (d: Doc) => {
    if (!editor) return;
    loading.current = true; curRef.current = d; setCur(d);
    editor.commands.setContent(d.html || "<p></p>", false);
    editor.setEditable(!d.meta.readOnly);
    loading.current = false; setDirty(false); setFileOpen(false); setTab("Home");
    localStorage.setItem("bd:last", d.id);
  };
  const create = async (html: string, title: string, meta?: Meta) => {
    if (dirty) await flush();
    const now = Date.now();
    const d: Doc = { id: uid(), title, html, meta: meta || defaultMeta(), created: now, updated: now };
    if (await persist(d)) load(d);
    return d;
  };
  const setMeta = (p: Partial<Meta>) => {
    const c = curRef.current; if (!c) return;
    const d = { ...c, meta: { ...c.meta, ...p }, updated: Date.now() };
    curRef.current = d; setCur(d); persist(d);
    if (p.readOnly !== undefined) editor?.setEditable(!p.readOnly);
  };
  const rename = async (d?: Doc) => {
    const t = d || curRef.current; if (!t) return;
    const n = await ask("Document name", t.title); if (!n || !n.trim()) return;
    if (!d || d.id === curRef.current?.id) { const c = { ...curRef.current!, title: n.trim() }; curRef.current = c; setCur(c); await persist(c); }
    else { await saveDoc({ ...d, title: n.trim() }); refresh(); }
  };
  const duplicate = async (d?: Doc) => {
    if (!d) await flush();
    const src = d || curRef.current; if (!src) return;
    const fresh = d ? (await getDoc(d.id))! : curRef.current!;
    const now = Date.now(); const copy: Doc = { ...fresh, id: uid(), title: fresh.title + " (copy)", created: now, updated: now, deleted: undefined };
    await saveDoc(copy); await refresh(); notify("Created “" + copy.title + "”");
  };
  const trash = async (d: Doc) => {
    if (!(await confirm("Delete document?", `“${d.title}” will move to Recently deleted. You can restore it later.`, "Delete"))) return;
    await saveDoc({ ...d, deleted: Date.now() }); await refresh();
    if (curRef.current?.id === d.id) { const rest = (await listDocs()).filter((x) => !x.deleted); rest[0] ? load(rest[0]) : create("<p></p>", "Untitled document"); }
  };
  const restore = async (d: Doc) => { await saveDoc({ ...d, deleted: undefined }); refresh(); };
  const purge = async (d: Doc) => { if (await confirm("Delete forever?", `“${d.title}” cannot be recovered after this.`, "Delete forever")) { await purgeDoc(d.id); refresh(); } };

  useEffect(() => {
    if (!editor) return;
    (async () => {
      const list = await listDocs(); setDocs(list);
      const last = list.find((d) => d.id === localStorage.getItem("bd:last") && !d.deleted) || list.find((d) => !d.deleted);
      if (last) { load(last); setStatus("Recovered last document"); } else create("<p></p>", "Untitled document");
    })();
  }, [editor]);

  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } };
    window.addEventListener("beforeunload", h);
    const vis = () => { if (document.visibilityState === "hidden") flush(); };
    document.addEventListener("visibilitychange", vis);
    return () => { window.removeEventListener("beforeunload", h); document.removeEventListener("visibilitychange", vis); };
  }, [dirty, flush]);

  // ---------- import / export ----------
  const base = () => (curRef.current?.title || "document").replace(/[\\/:*?"<>|]+/g, "_");
  const guard = async (what: string, fn: () => Promise<void>) => {
    try { await fn(); } catch (e: any) { info(what + " failed", String(e?.message || e)); }
  };
  const exportDocx = () => guard("DOCX export", async () => {
    const { blob, warnings } = await exportDocxBlob(editor!.getJSON() as any, curRef.current!.meta, curRef.current!.title);
    if (await saveBlob(base() + ".docx", blob)) {
      notify("Exported DOCX");
      info("DOCX exported", <div>The file was created. Exact pagination and some advanced formatting may differ in Microsoft Word. Not exported: comments, text boxes, borders/shading on paragraphs, character spacing.{warnings.map((w, i) => <p key={i}>⚠ {w}</p>)}</div>);
    }
  });
  const exportPdf = () => guard("PDF export", async () => {
    notify("Creating PDF…");
    const dom = document.querySelector(".ProseMirror") as HTMLElement;
    const blob = await exportPdfBlob(dom, curRef.current!.meta);
    if (await saveBlob(base() + ".pdf", blob)) notify("Exported PDF");
  });
  const exportTxt = () => guard("TXT export", async () => { await saveBlob(base() + ".txt", new Blob([editor!.getText({ blockSeparator: "\n" })], { type: "text/plain" })); });
  const exportHtml = () => guard("HTML export", async () => { await saveBlob(base() + ".html", new Blob([wrapHtml(curRef.current!.title, editor!.getHTML())], { type: "text/html" })); });
  const openFile = () => guard("Open", async () => {
    const f = await pickFile(".docx,.txt,.html,.htm,.md");
    if (!f) return;
    const ext = f.name.split(".").pop()!.toLowerCase(); const title = f.name.replace(/\.[^.]+$/, "");
    if (ext === "docx") {
      const r = await importDocx(f); await create(r.html, title);
      info("DOCX opened as a new document", <div>Your original file was not changed.{r.warnings.map((w, i) => <p key={i}>⚠ {w}</p>)}</div>);
    } else if (ext === "txt" || ext === "md") await create(textToHtml(await f.text()), title);
    else if (ext === "html" || ext === "htm") await create(await f.text(), title);
    else throw new Error("Unsupported file type: ." + ext + ". Supported: .docx, .txt, .html");
  });
  const backup = () => guard("Backup", async () => {
    await flush(); const all = await listDocs();
    await saveBlob(`BD-Word-backup-${new Date().toISOString().slice(0, 10)}.json`, new Blob([JSON.stringify({ app: "bd-word", version: 1, docs: all })], { type: "application/json" }));
  });
  const restoreBackup = () => guard("Restore", async () => {
    const f = await pickFile(".json"); if (!f) return;
    const j = JSON.parse(await f.text()); if (j.app !== "bd-word" || !Array.isArray(j.docs)) throw new Error("This is not a BD Word backup file.");
    const existing = new Set((await listDocs()).map((d) => d.id)); let n = 0;
    for (const d of j.docs as Doc[]) { await saveDoc(existing.has(d.id) ? { ...d, id: uid(), title: d.title + " (restored)" } : d); n++; } // never overwrite
    await refresh(); info("Restore complete", `${n} document(s) restored. Existing documents were not overwritten.`);
  });
  const print = () => {
    if (isNative()) { info("Printing on Android", "Use Export PDF, then print or share the PDF from your PDF viewer."); return; }
    window.print();
  };
  const fullscreen = () => { document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen?.(); };

  // ---------- view helpers ----------
  const meta = cur?.meta || defaultMeta();
  const [pw, ph] = pageMm(meta);
  const fit = (m: "width" | "page") => {
    const el = scrollRef.current; if (!el) return;
    const zw = (el.clientWidth - 40) / (pw * MM_PX); const zh = (el.clientHeight - 40) / (ph * MM_PX);
    setZoom(Math.max(0.25, Math.min(3, +(m === "width" ? zw : Math.min(zw, zh)).toFixed(2))));
  };
  useEffect(() => { if (window.innerWidth < 800) fit("width"); }, [pw, cur?.id]);
  useEffect(() => { localStorage.setItem("bd:dark", dark ? "1" : "0"); }, [dark]);
  useEffect(() => {
    let s = document.getElementById("page-style") as HTMLStyleElement | null;
    if (!s) { s = document.createElement("style"); s.id = "page-style"; document.head.appendChild(s); }
    const m = meta.margin;
    s.textContent = `@page{size:${pw}mm ${ph}mm;margin:${m.t}mm ${m.r}mm ${m.b}mm ${m.l}mm;${meta.pageNumbers ? `@bottom-${meta.pageNumPos}{content:counter(page)}` : ""}}`;
  }, [pw, ph, meta.margin, meta.pageNumbers, meta.pageNumPos]);
  useEffect(() => {
    if (!editor) return;
    editor.setOptions({ editorProps: { attributes: { lang: meta.language, spellcheck: String(meta.spellcheck), dir: "auto", "aria-label": "Document editor", role: "textbox" } } });
    editor.setEditable(!meta.readOnly && view !== "read");
  }, [editor, meta.language, meta.spellcheck, meta.readOnly, view]);
  useEffect(() => {
    if (!editor) return;
    const calc = () => {
      const sh = sheetRef.current; if (!sh) return;
      const pxPage = ph * MM_PX; const r = sh.getBoundingClientRect();
      const total = Math.max(1, Math.ceil(r.height / zoom / pxPage - 0.001));
      let current = 1;
      try { const c = editor.view.coordsAtPos(editor.state.selection.from); current = Math.min(total, Math.max(1, Math.floor((c.top - r.top) / zoom / pxPage) + 1)); } catch {}
      setPages({ total, current });
    };
    editor.on("transaction", calc); calc();
    return () => { editor.off("transaction", calc); };
  }, [editor, ph, zoom]);

  // ---------- shortcuts ----------
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (e.ctrlKey || e.metaKey) {
        if (k === "s") { e.preventDefault(); e.shiftKey ? rename() : flush(); }
        else if (k === "n") { e.preventDefault(); create("<p></p>", "Untitled document"); }
        else if (k === "o") { e.preventDefault(); openFile(); }
        else if (k === "p") { e.preventDefault(); print(); }
        else if (k === "f") { e.preventDefault(); setFind({ replace: false }); }
        else if (k === "h") { e.preventDefault(); setFind({ replace: true }); }
        else if (k === "enter") { e.preventDefault(); editor?.chain().focus().insertPageBreak().run(); }
        else if (k === "k") { e.preventDefault(); }
      } else if (e.key === "F11") { e.preventDefault(); fullscreen(); }
    };
    window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h);
  });

  const api: Api = { meta, setMeta, zoom, setZoom, fit, dark, setDark, nav, setNav, marks, setMarks, view, setView, openFind: (r) => setFind({ replace: r }), print, fullscreen, ask, info, notify };
  const fileApi: FileApi = {
    docs, cur, close: () => setFileOpen(false),
    newBlank: () => create("<p></p>", "Untitled document"),
    fromTemplate: (id) => { const t = TEMPLATES.find((x) => x.id === id)!; create(t.html, t.name); },
    openDoc: async (d) => { if (dirty) await flush(); const f = await getDoc(d.id); if (f) load(f); },
    openFile, save: async () => { if (await flush()) notify("Saved"); }, rename, duplicate, trash, restore, purge,
    saveCopy: () => duplicate(), exportDocx, exportPdf, exportTxt, exportHtml, print, backup, restoreBackup,
    props: () => editor && info("Word count", `Words: ${editor.storage.characterCount.words()} · Characters: ${editor.storage.characterCount.characters()}`),
    closeDoc: async () => { await flush(); const rest = (await listDocs()).filter((x) => x.id !== curRef.current?.id && !x.deleted); rest[0] ? load(rest[0]) : create("<p></p>", "Untitled document"); },
  };

  const outline = useMemo(() => {
    const out: { level: number; text: string; pos: number }[] = [];
    editor?.state.doc.descendants((n, pos) => { if (n.type.name === "heading") out.push({ level: n.attrs.level, text: n.textContent || "(empty heading)", pos }); });
    return out;
  }, [editor?.state.doc]);
  const goto = (pos: number) => { editor?.chain().focus().setTextSelection(pos + 1).scrollIntoView().run(); if (window.innerWidth < 800) setNav(false); };

  const m = meta.margin;
  const sheetStyle: React.CSSProperties = view === "print" ? {
    width: `${pw}mm`, minHeight: `${ph}mm`, padding: `${m.t}mm ${m.r}mm ${m.b}mm ${m.l}mm`, background: meta.pageColor,
    backgroundImage: "linear-gradient(to bottom, transparent calc(100% - 2px), rgba(0,0,0,.22) 100%)", backgroundSize: `100% ${ph}mm`,
  } : { width: "100%", maxWidth: view === "read" ? 720 : 900, padding: "24px 28px", background: meta.pageColor, minHeight: "80vh" };
  const words = editor?.storage.characterCount.words() ?? 0;
  const sel = editor ? editor.state.doc.textBetween(editor.state.selection.from, editor.state.selection.to, " ").trim().split(/\s+/).filter(Boolean).length : 0;

  return (
    <div className={"app" + (dark ? " dark" : "") + (marks ? " marks" : "")}>
      <header className="titlebar">
        <span className="logo">BD Word</span>
        <input className="title" aria-label="Document name" value={cur?.title || ""} onChange={(e) => { const c = { ...curRef.current!, title: e.target.value }; curRef.current = c; setCur(c); scheduleRef.current(); }} />
        <span className={"saved" + (saveErr ? " err" : "")}>{saveErr ? "⚠ NOT SAVED" : dirty ? "● Unsaved changes" : "✓ Saved"}</span>
        <button className="tb" disabled={!editor?.can().undo()} onClick={() => editor?.chain().focus().undo().run()} aria-label="Undo">↶</button>
        <button className="tb" disabled={!editor?.can().redo()} onClick={() => editor?.chain().focus().redo().run()} aria-label="Redo">↷</button>
      </header>
      <nav className="tabs" role="tablist">{TABS.map((t) => (
        <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? "on" : ""} onClick={() => (t === "File" ? setFileOpen(true) : setTab(t))}>{t}</button>))}
      </nav>
      {editor && <Ribbon tab={tab === "File" ? "Home" : tab} ed={editor} api={api} />}
      <main className="workspace">
        {nav && <aside className="navpane"><h4>Navigation</h4>{outline.length ? outline.map((o, i) => <button key={i} style={{ paddingLeft: 8 + (o.level - 1) * 12 }} onClick={() => goto(o.pos)}>{o.text}</button>) : <p className="muted">Add headings (Home → Styles) to see an outline.</p>}</aside>}
        <div className="scroll" ref={scrollRef}>
          <div className="zoomwrap" style={{ zoom } as any}>
            {view === "print" && <Ruler pw={pw} m={m} />}
            <div className={"sheet " + view} style={sheetStyle} ref={sheetRef}>
              {meta.header && <div className="hdr">{meta.header}</div>}
              <div style={{ columnCount: meta.columns > 1 ? meta.columns : undefined, columnGap: "10mm" }}><EditorContent editor={editor} /></div>
              {(meta.footer || meta.pageNumbers) && <div className="ftr" style={{ textAlign: meta.pageNumPos }}>{meta.footer}{meta.footer && meta.pageNumbers ? "   " : ""}{meta.pageNumbers ? `Page ${pages.current}` : ""}</div>}
            </div>
          </div>
        </div>
      </main>
      {find && editor && <FindBar ed={editor} replace={find.replace} onClose={() => setFind(null)} />}
      <footer className="status">
        <span>Page {pages.current} of {pages.total}</span><span>{words} words{sel ? ` (${sel} selected)` : ""}</span>
        <span>{{ en: "English", "en-GB": "English (UK)", bn: "বাংলা" }[meta.language] || meta.language}</span><span className="grow">{status}</span>
        <input type="range" min={25} max={300} value={Math.round(zoom * 100)} aria-label="Zoom" onChange={(e) => setZoom(+e.target.value / 100)} /><span>{Math.round(zoom * 100)}%</span>
      </footer>
      {fileOpen && <FileView a={fileApi} />}
      {modal && <Modal m={modal} close={() => setModal(null)} />}
    </div>
  );
}

function Ruler({ pw, m }: { pw: number; m: Meta["margin"] }) {
  const ticks = Array.from({ length: Math.floor(pw / 10) + 1 }, (_, i) => i);
  return (
    <div className="ruler" style={{ width: `${pw}mm` }} aria-hidden>
      <div className="rm" style={{ left: 0, width: `${m.l}mm` }} /><div className="rm" style={{ right: 0, width: `${m.r}mm` }} />
      {ticks.map((i) => <span key={i} style={{ left: `${i * 10}mm` }}>{i > 0 ? i : ""}</span>)}
    </div>
  );
}
