// @ts-ignore
import html2pdf from "html2pdf.js";
import { Meta, pageMm } from "../types";

/** Renders the document body to a PDF Blob. Note: PDF pages are rendered as images (text is not selectable). */
export async function exportPdfBlob(editorDom: HTMLElement, meta: Meta): Promise<Blob> {
  const [w, h] = pageMm(meta);
  const wrap = document.createElement("div");
  wrap.style.cssText = `position:fixed;left:-10000px;top:0;width:${w - meta.margin.l - meta.margin.r}mm;background:#fff;color:#000`;
  const clone = editorDom.cloneNode(true) as HTMLElement;
  clone.removeAttribute("contenteditable");
  clone.style.cssText = "padding:0;margin:0;color:#000;background:#fff";
  wrap.appendChild(clone);
  document.body.appendChild(wrap);
  try {
    const m = meta.margin;
    const out = await html2pdf()
      .set({
        margin: [m.t, m.r, m.b, m.l],
        image: { type: "jpeg", quality: 0.95 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: "mm", format: [w, h], orientation: w > h ? "landscape" : "portrait" },
        pagebreak: { mode: ["css", "legacy"] },
      })
      .from(wrap)
      .outputPdf("blob");
    return out as Blob;
  } finally {
    wrap.remove();
  }
}
