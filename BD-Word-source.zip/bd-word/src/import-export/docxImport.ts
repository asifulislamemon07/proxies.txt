// @ts-ignore - browser build has no bundled types
import mammoth from "mammoth/mammoth.browser";

export async function importDocx(file: File): Promise<{ html: string; warnings: string[] }> {
  const arrayBuffer = await file.arrayBuffer();
  const r = await mammoth.convertToHtml({ arrayBuffer });
  const warnings = (r.messages || []).map((m: any) => m.message);
  warnings.unshift("Imported from DOCX: headers/footers, text boxes, comments, tracked changes, footnotes and exact pagination are not imported.");
  return { html: r.value || "<p></p>", warnings: [...new Set<string>(warnings)] };
}
