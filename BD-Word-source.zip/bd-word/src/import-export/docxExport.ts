import {
  AlignmentType, BorderStyle, Document, ExternalHyperlink, Footer, Header, HeadingLevel, ImageRun, LevelFormat,
  Packer, PageBreak, PageNumber, PageOrientation, Paragraph, ShadingType, Table, TableCell, TableRow,
  TextRun, UnderlineType, WidthType,
} from "docx";
import { Meta, PAGE_SIZES } from "../types";

type N = { type?: string; text?: string; attrs?: any; marks?: { type: string; attrs?: any }[]; content?: N[] };
interface Ctx { inst: number; warnings: string[]; indent: number }

const tw = (mm: number) => Math.round(mm * 56.6929);
const hex = (c?: string | null) => {
  if (!c) return undefined;
  const m = c.match(/^#([0-9a-f]{6})$/i);
  if (m) return m[1];
  const r = c.match(/rgba?\((\d+)\D+(\d+)\D+(\d+)/);
  return r ? [r[1], r[2], r[3]].map((x) => (+x).toString(16).padStart(2, "0")).join("") : undefined;
};
const align = (a?: string) =>
  a === "center" ? AlignmentType.CENTER : a === "right" ? AlignmentType.RIGHT : a === "justify" ? AlignmentType.JUSTIFIED : AlignmentType.LEFT;
const HEADS = [undefined, HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3, HeadingLevel.HEADING_4, HeadingLevel.HEADING_5, HeadingLevel.HEADING_6];
const px2tw = (v?: string | null) => (v ? Math.round(parseFloat(v) * 15) : 0);

function dataUrl(src: string) {
  const m = src?.match(/^data:image\/(png|jpe?g|gif|bmp);base64,(.+)$/i);
  if (!m) return null;
  const bin = atob(m[2]);
  const data = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) data[i] = bin.charCodeAt(i);
  return { type: m[1].toLowerCase().replace("jpeg", "jpg") as "png" | "jpg" | "gif" | "bmp", data };
}
function naturalSize(src: string): Promise<[number, number]> {
  if (typeof Image === "undefined") return Promise.resolve([300, 200]);
  return new Promise((res) => {
    const i = new Image();
    i.onload = () => res([i.naturalWidth || 300, i.naturalHeight || 200]);
    i.onerror = () => res([300, 200]);
    i.src = src;
  });
}

async function inline(nodes: N[] | undefined, base: any, ctx: Ctx, imgAlign?: string): Promise<any[]> {
  const out: any[] = [];
  for (const n of nodes || []) {
    if (n.type === "hardBreak") { out.push(new TextRun({ break: 1 })); continue; }
    if (n.type === "image") {
      const d = dataUrl(n.attrs?.src);
      if (!d) { ctx.warnings.push("An image in an unsupported format (e.g. WebP/SVG) was skipped in the DOCX export."); continue; }
      const [nw, nh] = await naturalSize(n.attrs.src);
      let w = n.attrs.width ? parseFloat(n.attrs.width) : Math.min(nw, 450);
      if (!isFinite(w) || w <= 0) w = Math.min(nw, 450);
      out.push(new ImageRun({ type: d.type, data: d.data, transformation: { width: Math.round(w), height: Math.round((w * nh) / nw) }, altText: { title: n.attrs.alt || "image", description: n.attrs.alt || "image", name: "image" } } as any));
      continue;
    }
    if (n.type !== "text") continue;
    const o: any = { text: n.text || "", ...base };
    let link: string | undefined;
    for (const m of n.marks || []) {
      switch (m.type) {
        case "bold": o.bold = true; break;
        case "italic": o.italics = true; break;
        case "underline": o.underline = { type: UnderlineType.SINGLE }; break;
        case "strike": o.strike = true; break;
        case "subscript": o.subScript = true; break;
        case "superscript": o.superScript = true; break;
        case "code": o.font = "Courier New"; break;
        case "highlight": o.shading = { type: ShadingType.CLEAR, fill: hex(m.attrs?.color) || "FFFF00", color: "auto" }; break;
        case "link": link = m.attrs?.href; break;
        case "textStyle": {
          const a = m.attrs || {};
          if (a.color) o.color = hex(a.color);
          if (a.fontSize) { const v = parseFloat(a.fontSize); o.size = Math.round((String(a.fontSize).endsWith("pt") ? v : v * 0.75) * 2); }
          if (a.fontFamily) { const f = String(a.fontFamily).split(",")[0].replace(/["']/g, "").trim(); o.font = { ascii: f, hAnsi: f, cs: f, eastAsia: f }; }
          break;
        }
      }
    }
    if (link) { o.color = o.color || "0563C1"; o.underline = { type: UnderlineType.SINGLE }; }
    const r = new TextRun(o);
    out.push(link ? new ExternalHyperlink({ link, children: [r] }) : r);
  }
  return out;
}

async function para(n: N, ctx: Ctx, list?: { ref: string; level: number; inst: number }): Promise<Paragraph> {
  const a = n.attrs || {};
  const base: any = {};
  let alignment = align(a.textAlign);
  if (a.pstyle === "title") { base.size = 56; base.bold = true; alignment = a.textAlign ? alignment : AlignmentType.CENTER; }
  if (a.pstyle === "subtitle") { base.size = 32; base.color = "666666"; alignment = a.textAlign ? alignment : AlignmentType.CENTER; }
  if (a.pstyle === "caption") { base.size = 18; base.italics = true; base.color = "595959"; }
  const opt: any = { children: await inline(n.content, base, ctx), alignment, spacing: {} };
  if (n.type === "heading") opt.heading = HEADS[a.level] || HeadingLevel.HEADING_1;
  if (list) opt.numbering = { reference: list.ref, level: Math.min(list.level, 5), instance: list.inst };
  if (a.lineHeight) { opt.spacing.line = Math.round(parseFloat(a.lineHeight) * 240); }
  if (a.marginTop) opt.spacing.before = px2tw(a.marginTop);
  if (a.marginBottom) opt.spacing.after = px2tw(a.marginBottom);
  const left = px2tw(a.marginLeft) + ctx.indent;
  if (left) opt.indent = { left };
  return new Paragraph(opt);
}

async function listBlocks(n: N, ctx: Ctx, level: number): Promise<(Paragraph | Table)[]> {
  const ref = n.type === "orderedList" ? "numbers" : "bullets";
  const inst = ctx.inst++;
  const out: (Paragraph | Table)[] = [];
  for (const li of n.content || []) {
    for (const c of li.content || []) {
      if (c.type === "bulletList" || c.type === "orderedList") out.push(...(await listBlocks(c, ctx, level + 1)));
      else if (c.type === "paragraph" || c.type === "heading") out.push(await para(c, ctx, { ref, level, inst }));
      else out.push(...(await block(c, ctx)));
    }
  }
  return out;
}

async function block(n: N, ctx: Ctx): Promise<(Paragraph | Table)[]> {
  switch (n.type) {
    case "paragraph": case "heading": {
      // block-level image inside paragraph handled by inline(); image node itself:
      return [await para(n, ctx)];
    }
    case "image": {
      return [new Paragraph({ alignment: align(n.attrs?.align), children: await inline([n], {}, ctx) })];
    }
    case "bulletList": case "orderedList": return listBlocks(n, ctx, 0);
    case "blockquote": {
      const c2 = { ...ctx, indent: ctx.indent + 720 };
      const out: any[] = [];
      for (const c of n.content || []) out.push(...(await block(c, c2)));
      return out;
    }
    case "codeBlock": {
      const text = (n.content || []).map((x) => x.text || "").join("");
      return text.split("\n").map((line) => new Paragraph({ children: [new TextRun({ text: line, font: "Courier New", size: 20 })] }));
    }
    case "horizontalRule": return [new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "999999", space: 1 } } })];
    case "pageBreak": return [new Paragraph({ children: [new PageBreak()] })];
    case "toc": {
      const items = n.attrs?.items || [];
      return [new Paragraph({ children: [new TextRun({ text: "Table of Contents", bold: true, size: 28 })] }),
        ...items.map((i: any) => new Paragraph({ indent: { left: (i.level - 1) * 360 }, children: [new TextRun(i.text)] }))];
    }
    case "table": {
      const rows: TableRow[] = [];
      for (const r of n.content || []) {
        const cells: TableCell[] = [];
        for (const c of r.content || []) {
          const kids: any[] = [];
          for (const x of c.content || []) kids.push(...(await block(x, ctx)));
          const fill = hex(c.attrs?.backgroundColor);
          cells.push(new TableCell({
            children: kids.length ? kids : [new Paragraph("")],
            columnSpan: c.attrs?.colspan > 1 ? c.attrs.colspan : undefined,
            rowSpan: c.attrs?.rowspan > 1 ? c.attrs.rowspan : undefined,
            shading: fill ? { type: ShadingType.CLEAR, fill, color: "auto" } : undefined,
          }));
        }
        rows.push(new TableRow({ children: cells, tableHeader: r.content?.[0]?.type === "tableHeader" }));
      }
      return [new Table({ rows, width: { size: 100, type: WidthType.PERCENTAGE } }), new Paragraph("")];
    }
    default: {
      const out: any[] = [];
      for (const c of n.content || []) out.push(...(await block(c, ctx)));
      return out;
    }
  }
}

const levels = (fmt: any, text: (i: number) => string) =>
  Array.from({ length: 6 }, (_, i) => ({ level: i, format: fmt, text: text(i), alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720 + i * 360, hanging: 360 } } } }));

export async function buildDocx(json: N, meta: Meta, title: string): Promise<{ doc: Document; warnings: string[] }> {
  const ctx: Ctx = { inst: 1, warnings: [], indent: 0 };
  const children: any[] = [];
  for (const n of json.content || []) children.push(...(await block(n, ctx)));
  if (!children.length) children.push(new Paragraph(""));
  const [w, h] = PAGE_SIZES[meta.pageSize] || PAGE_SIZES.A4;
  const m = meta.margin;
  const props: any = {
    page: {
      size: { width: tw(w), height: tw(h), orientation: meta.landscape ? PageOrientation.LANDSCAPE : PageOrientation.PORTRAIT },
      margin: { top: tw(m.t), bottom: tw(m.b), left: tw(m.l), right: tw(m.r) },
    },
  };
  if (meta.columns > 1) props.column = { count: meta.columns, space: 708 };
  const section: any = { properties: props, children };
  if (meta.header) section.headers = { default: new Header({ children: [new Paragraph({ children: [new TextRun(meta.header)] })] }) };
  if (meta.footer || meta.pageNumbers) {
    const kids: any[] = [];
    if (meta.footer) kids.push(new TextRun(meta.footer + (meta.pageNumbers ? "    " : "")));
    if (meta.pageNumbers) kids.push(new TextRun({ children: [PageNumber.CURRENT] }));
    section.footers = { default: new Footer({ children: [new Paragraph({ alignment: align(meta.pageNumPos), children: kids })] }) };
  }
  const doc = new Document({
    title, creator: "BD Word",
    styles: { default: { document: { run: { font: { ascii: "Calibri", hAnsi: "Calibri", cs: "Nirmala UI", eastAsia: "Calibri" }, size: 22 } } } },
    numbering: { config: [
      { reference: "bullets", levels: levels(LevelFormat.BULLET, () => "•") },
      { reference: "numbers", levels: levels(LevelFormat.DECIMAL, (i) => `%${i + 1}.`) },
    ] },
    sections: [section],
  });
  return { doc, warnings: [...new Set(ctx.warnings)] };
}

export async function exportDocxBlob(json: N, meta: Meta, title: string) {
  const { doc, warnings } = await buildDocx(json, meta, title);
  return { blob: await Packer.toBlob(doc), warnings };
}
