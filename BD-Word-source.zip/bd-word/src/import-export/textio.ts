const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
export const textToHtml = (t: string) => t.replace(/\r\n?/g, "\n").split("\n").map((l) => `<p>${esc(l)}</p>`).join("");
export const wrapHtml = (title: string, body: string) =>
  `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>body{font-family:Calibri,'Nirmala UI',sans-serif;max-width:800px;margin:2rem auto;line-height:1.5}table{border-collapse:collapse}td,th{border:1px solid #999;padding:4px 8px}img{max-width:100%}</style></head><body>${body}</body></html>`;
