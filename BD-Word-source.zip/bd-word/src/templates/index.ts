export interface Template { id: string; name: string; group: string; html: string }
const L = (s: string) => `<p>${s}</p>`;
const table = (rows: string[][], head = true) =>
  `<table><tbody>${rows.map((r, i) => `<tr>${r.map((c) => (head && i === 0 ? `<th><p>${c}</p></th>` : `<td><p>${c}</p></td>`)).join("")}</tr>`).join("")}</tbody></table>`;

export const TEMPLATES: Template[] = [
  { id: "blank", name: "Blank document", group: "Basic", html: "<p></p>" },
  { id: "cv-pro", name: "Professional CV", group: "CV", html:
    `<h1 style="text-align:center">Your Full Name</h1><p style="text-align:center">Address · Phone · email@example.com</p><hr>
<h2>Career Objective</h2>${L("Write 2–3 sentences about your goals and strengths.")}
<h2>Work Experience</h2><p><strong>Job Title</strong> — Company Name <em>(2021 – Present)</em></p><ul><li><p>Key achievement or responsibility</p></li><li><p>Key achievement or responsibility</p></li></ul>
<h2>Education</h2><p><strong>Degree / Program</strong> — Institution <em>(Year)</em></p>
<h2>Skills</h2><ul><li><p>Skill one</p></li><li><p>Skill two</p></li><li><p>Skill three</p></li></ul>
<h2>Languages</h2>${L("Bangla (Native) · English (Professional)")}
<h2>References</h2>${L("Available on request.")}` },
  { id: "cv-modern", name: "Modern résumé (two-column)", group: "CV", html:
    `<h1>Your Full Name</h1><p>Job Title · email@example.com · +880 1XXX-XXXXXX</p>` +
    table([["Profile / Skills", "Experience / Education"], ["<strong>Profile</strong><br>Short summary.<br><br><strong>Skills</strong><br>• Skill one<br>• Skill two", "<strong>Experience</strong><br>Job Title — Company (Years)<br>• Achievement<br><br><strong>Education</strong><br>Degree — Institution (Year)"]]) },
  { id: "cv-student", name: "Student CV", group: "CV", html:
    `<h1>Student Name</h1><p>Class / Department · Institution · Phone · Email</p><hr>
<h2>Objective</h2>${L("Short statement about what you are seeking (internship, scholarship, part-time job).")}
<h2>Education</h2><ul><li><p>SSC / HSC / Current program — Institution, GPA, Year</p></li></ul>
<h2>Projects & Activities</h2><ul><li><p>Project or club activity</p></li></ul>
<h2>Skills</h2><ul><li><p>Computer skills · Languages · Communication</p></li></ul>` },
  { id: "app-job", name: "Job application", group: "Letters", html:
    `<p>Date: ____</p><p>The Hiring Manager<br>Company Name<br>Address</p><p><strong>Subject: Application for the post of [Position]</strong></p><p>Dear Sir/Madam,</p>${L("I am writing to apply for the position of [Position] as advertised. I have [X years] of experience in … and believe I am a strong fit because …")}${L("I have attached my CV for your consideration. I would welcome an interview at your convenience.")}<p>Yours faithfully,<br>Your Name<br>Phone · Email</p>` },
  { id: "cover", name: "Cover letter", group: "Letters", html:
    `<p>Your Name<br>Address<br>Phone · Email</p><p>Date</p><p>Recipient Name<br>Company<br>Address</p><p>Dear [Name],</p>${L("Opening paragraph: the role and why you are excited.")}${L("Middle paragraph: relevant skills and results.")}${L("Closing paragraph: thank them and request a meeting.")}<p>Sincerely,<br>Your Name</p>` },
  { id: "letter-biz", name: "Business letter", group: "Letters", html:
    `<p><strong>Company Name</strong><br>Address · Phone · Email</p><hr><p>Date</p><p>Recipient<br>Address</p><p><strong>Subject: …</strong></p><p>Dear Sir/Madam,</p>${L("Body of the letter.")}<p>Yours sincerely,<br>Name<br>Designation</p>` },
  { id: "leave", name: "Leave application", group: "Letters", html:
    `<p>Date: ____</p><p>The Principal / Manager<br>Institution / Company<br>Address</p><p><strong>Subject: Application for leave</strong></p><p>Respected Sir/Madam,</p>${L("I respectfully state that I am unable to attend from [start date] to [end date] due to [reason]. I therefore request you to kindly grant me leave for the said period.")}<p>Yours obediently,<br>Name<br>Class/Roll or ID</p>` },
  { id: "internship", name: "Internship application", group: "Letters", html:
    `<p>Date: ____</p><p>The HR Manager<br>Company</p><p><strong>Subject: Application for internship in [Department]</strong></p><p>Dear Sir/Madam,</p>${L("I am a [year] student of [department] at [institution]. I am eager to gain practical experience in …")}<p>Sincerely,<br>Name · Phone · Email</p>` },
  { id: "assign", name: "School/College assignment", group: "Academic", html:
    `<p class="st-title" data-style="title" style="">Assignment Title</p><p style="text-align:center">Course: ____ &nbsp; Code: ____</p><p style="text-align:center">Submitted by: Name · Roll · Section<br>Submitted to: Teacher Name<br>Date: ____</p><h1>Introduction</h1><p></p><h1>Discussion</h1><p></p><h1>Conclusion</h1><p></p>` },
  { id: "report-academic", name: "Academic report", group: "Academic", html:
    `<h1 style="text-align:center">Report Title</h1><p style="text-align:center">Author · Institution · Date</p><h2>Abstract</h2><p></p><h2>1. Introduction</h2><p></p><h2>2. Methodology</h2><p></p><h2>3. Results</h2><p></p><h2>4. Conclusion</h2><p></p><h2>References</h2><p></p>` },
  { id: "report-project", name: "Project report", group: "Business", html:
    `<h1>Project Report</h1>` + table([["Project", "Name"], ["Prepared by", "Name"], ["Date", "____"], ["Status", "On track"]], false) + `<h2>Summary</h2><p></p><h2>Progress</h2><p></p><h2>Risks & Issues</h2><p></p><h2>Next Steps</h2><p></p>` },
  { id: "minutes", name: "Meeting minutes", group: "Business", html:
    `<h1>Meeting Minutes</h1><p>Date: ____ &nbsp; Time: ____ &nbsp; Venue: ____</p><p>Attendees: ____</p><h2>Agenda</h2><ol><li><p>Item</p></li></ol><h2>Decisions</h2><ul><li><p>Decision</p></li></ul>` +
    table([["Action", "Owner", "Due"], ["", "", ""]]) },
  { id: "proposal", name: "Business proposal", group: "Business", html:
    `<h1 style="text-align:center">Business Proposal</h1><p style="text-align:center">Prepared for [Client] by [Company]</p><h2>Executive Summary</h2><p></p><h2>Problem</h2><p></p><h2>Proposed Solution</h2><p></p><h2>Timeline</h2><p></p><h2>Budget</h2><p></p>` },
  { id: "invoice", name: "Invoice", group: "Business", html:
    `<h1>INVOICE</h1><p>Invoice No: ____ &nbsp; Date: ____<br>Bill to: Customer Name, Address</p>` +
    table([["Description", "Qty", "Unit price", "Amount"], ["Item", "1", "0.00", "0.00"], ["", "", "", ""], ["", "", "Total", "0.00"]]) + `<p>Payment terms: ____</p>` },
  { id: "quote", name: "Simple quotation", group: "Business", html:
    `<h1>QUOTATION</h1><p>Quote No: ____ &nbsp; Valid until: ____<br>To: Customer Name</p>` +
    table([["Item", "Qty", "Rate", "Total"], ["", "", "", ""], ["", "", "Grand total", ""]]) },
  { id: "report-table", name: "Table-based report", group: "Business", html:
    `<h1>Report</h1><p>Period: ____</p>` + table([["No.", "Item", "Details", "Remarks"], ["1", "", "", ""], ["2", "", "", ""], ["3", "", "", ""]]) },
  { id: "certificate", name: "Certificate", group: "Basic", html:
    `<p style="text-align:center"><br></p><h1 style="text-align:center">CERTIFICATE OF ACHIEVEMENT</h1><p style="text-align:center">This is proudly presented to</p><h1 style="text-align:center">Recipient Name</h1><p style="text-align:center">for outstanding …</p><p style="text-align:center"><br>Date: ____ &nbsp;&nbsp;&nbsp; Signature: ____</p>` },
  { id: "book", name: "Book manuscript", group: "Basic", html:
    `<p class="st-title" data-style="title">Book Title</p><p style="text-align:center" data-style="subtitle" class="st-subtitle">Author Name</p><div data-page-break class="page-break"></div><h1>Chapter 1</h1><p style="line-height:1.8"></p><div data-page-break class="page-break"></div><h1>Chapter 2</h1><p></p>` },
];
